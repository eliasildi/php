<?php

// mostrar por pantalla los numeros impares menores que 100

$i = 1;

while ( $i <= 100){
	echo "$i <br />";
	$i = $i + 2;
}

?>